import org.junit.Before;
import org.junit.Test;

import cs3500.hw02.Card;
import cs3500.hw02.Suit;
import cs3500.hw02.Value;

import static org.junit.Assert.assertEquals;

/**
 * Created by cWong on 1/24/17.
 */
public class CardTest {
  private Card c1;
  private Card c2;
  private Card c3;
  private Card c4;

  /**
   * This method sets up test variables.
   *
   * @throws Exception if setup is not executed properly
   */
  @Before
  public void setUp() throws Exception {
    c1 = new Card(Value.ACE, Suit.HEART);
    c2 = new Card(Value.EIGHT, Suit.CLUB);
    c3 = new Card(Value.JACK, Suit.SPADE);
    c4 = new Card(Value.KING, Suit.DIAMOND);
  }

  @Test
  public void testToString_1() {
    assertEquals("A♥", c1.toString());
  }

  @Test
  public void testToString_2() {
    assertEquals("8♣", c2.toString());
  }

  @Test
  public void testToString_3() {
    assertEquals("J♠", c3.toString());
  }

  @Test
  public void testToString_4() {
    assertEquals("K♦", c4.toString());
  }
}