/**
 * Created by cWong on 1/24/17.
 */

import org.junit.Before;
import org.junit.Test;

import cs3500.hw02.FreecellModel;
import cs3500.hw02.PileType;

import static org.junit.Assert.assertEquals;

public class FreecellModelMove {
  private FreecellModel game;

  /**
   * This method sets up test variables.
   */
  @Before
  public void setUp() throws Exception {
    game = new FreecellModel();

  }

  // test moving from cascade to open
  @Test
  public void testMove1() {
    String expectedGameState =
            "F1:\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1: A♠\n"
                    + "O2:\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1:\n"
                    + "C2: 2♠\n"
                    + "C3: 3♠\n"
                    + "C4: 4♠\n"
                    + "C5: 5♠\n"
                    + "C6: 6♠\n"
                    + "C7: 8♠\n"
                    + "C8: 7♠\n"
                    + "C9: 9♠\n"
                    + "C10: 10♠\n"
                    + "C11: J♠\n"
                    + "C12: Q♠\n"
                    + "C13: K♠\n"
                    + "C14: A♥\n"
                    + "C15: 2♥\n"
                    + "C16: 3♥\n"
                    + "C17: 4♥\n"
                    + "C18: 5♥\n"
                    + "C19: 6♥\n"
                    + "C20: 8♥\n"
                    + "C21: 7♥\n"
                    + "C22: 9♥\n"
                    + "C23: 10♥\n"
                    + "C24: J♥\n"
                    + "C25: Q♥\n"
                    + "C26: K♥\n"
                    + "C27: A♦\n"
                    + "C28: 2♦\n"
                    + "C29: 3♦\n"
                    + "C30: 4♦\n"
                    + "C31: 5♦\n"
                    + "C32: 6♦\n"
                    + "C33: 8♦\n"
                    + "C34: 7♦\n"
                    + "C35: 9♦\n"
                    + "C36: 10♦\n"
                    + "C37: J♦\n"
                    + "C38: Q♦\n"
                    + "C39: K♦\n"
                    + "C40: A♣\n"
                    + "C41: 2♣\n"
                    + "C42: 3♣\n"
                    + "C43: 4♣\n"
                    + "C44: 5♣\n"
                    + "C45: 6♣\n"
                    + "C46: 8♣\n"
                    + "C47: 7♣\n"
                    + "C48: 9♣\n"
                    + "C49: 10♣\n"
                    + "C50: J♣\n"
                    + "C51: Q♣\n"
                    + "C52: K♣";

    game.startGame(game.getDeck(), 52, 4, false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    assertEquals(expectedGameState, game.getGameState());
  }

  // TODO: test moving from cascade to foundation

  // test moving from cascade to cascade
  @Test
  public void testMove3() {
    String expectedGameState =
            "F1:\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1:\n"
                    + "O2:\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1: A♠\n"
                    + "C2: 2♠\n"
                    + "C3: 3♠, 2♥\n"
                    + "C4: 4♠\n"
                    + "C5: 5♠\n"
                    + "C6: 6♠\n"
                    + "C7: 8♠\n"
                    + "C8: 7♠\n"
                    + "C9: 9♠\n"
                    + "C10: 10♠\n"
                    + "C11: J♠\n"
                    + "C12: Q♠\n"
                    + "C13: K♠\n"
                    + "C14: A♥\n"
                    + "C15:\n"
                    + "C16: 3♥\n"
                    + "C17: 4♥\n"
                    + "C18: 5♥\n"
                    + "C19: 6♥\n"
                    + "C20: 8♥\n"
                    + "C21: 7♥\n"
                    + "C22: 9♥\n"
                    + "C23: 10♥\n"
                    + "C24: J♥\n"
                    + "C25: Q♥\n"
                    + "C26: K♥\n"
                    + "C27: A♦\n"
                    + "C28: 2♦\n"
                    + "C29: 3♦\n"
                    + "C30: 4♦\n"
                    + "C31: 5♦\n"
                    + "C32: 6♦\n"
                    + "C33: 8♦\n"
                    + "C34: 7♦\n"
                    + "C35: 9♦\n"
                    + "C36: 10♦\n"
                    + "C37: J♦\n"
                    + "C38: Q♦\n"
                    + "C39: K♦\n"
                    + "C40: A♣\n"
                    + "C41: 2♣\n"
                    + "C42: 3♣\n"
                    + "C43: 4♣\n"
                    + "C44: 5♣\n"
                    + "C45: 6♣\n"
                    + "C46: 8♣\n"
                    + "C47: 7♣\n"
                    + "C48: 9♣\n"
                    + "C49: 10♣\n"
                    + "C50: J♣\n"
                    + "C51: Q♣\n"
                    + "C52: K♣";

    game.startGame(game.getDeck(), 52, 4, false);
    game.move(PileType.CASCADE, 14, 0, PileType.CASCADE, 2);
    assertEquals(expectedGameState, game.getGameState());
  }

  //  // test moving from open to cascade
  //  @Test
  //  public void testMove4() {
  //    String expectedGameState =
  //            "F1:\n"
  //                    + "F2:\n"
  //                    + "F3:\n"
  //                    + "F4:\n"
  //                    + "O1:\n"
  //                    + "O2:\n"
  //                    + "O3:\n"
  //                    + "O4:\n"
  //                    + "C1: A♠\n"
  //                    + "C2: 2♠\n"
  //                    + "C3: 3♠\n"
  //                    + "C4: 4♠\n"
  //                    + "C5: 5♠\n"
  //                    + "C6: 6♠\n"
  //                    + "C7: 8♠\n"
  //                    + "C8: 7♠\n"
  //                    + "C9: 9♠\n"
  //                    + "C10: 10♠\n"
  //                    + "C11: J♠\n"
  //                    + "C12: Q♠, J♥\n"
  //                    + "C13: K♠\n"
  //                    + "C14: A♥\n"
  //                    + "C15: 2♥\n"
  //                    + "C16: 3♥\n"
  //                    + "C17: 4♥\n"
  //                    + "C18: 5♥\n"
  //                    + "C19: 6♥\n"
  //                    + "C20: 8♥\n"
  //                    + "C21: 7♥\n"
  //                    + "C22: 9♥\n"
  //                    + "C23: 10♥\n"
  //                    + "C24:\n"
  //                    + "C25: Q♥\n"
  //                    + "C26: K♥\n"
  //                    + "C27: A♦\n"
  //                    + "C28: 2♦\n"
  //                    + "C29: 3♦\n"
  //                    + "C30: 4♦\n"
  //                    + "C31: 5♦\n"
  //                    + "C32: 6♦\n"
  //                    + "C33: 8♦\n"
  //                    + "C34: 7♦\n"
  //                    + "C35: 9♦\n"
  //                    + "C36: 10♦\n"
  //                    + "C37: J♦\n"
  //                    + "C38: Q♦\n"
  //                    + "C39: K♦\n"
  //                    + "C40: A♣\n"
  //                    + "C41: 2♣\n"
  //                    + "C42: 3♣\n"
  //                    + "C43: 4♣\n"
  //                    + "C44: 5♣\n"
  //                    + "C45: 6♣\n"
  //                    + "C46: 8♣\n"
  //                    + "C47: 7♣\n"
  //                    + "C48: 9♣\n"
  //                    + "C49: 10♣\n"
  //                    + "C50: J♣\n"
  //                    + "C51: Q♣\n"
  //                    + "C52: K♣";
  //
  //    game.startGame(game.getDeck(), 52, 4, false);
  //    game.move(PileType.CASCADE, 10, 0, PileType.OPEN, 0);
  //    game.move(PileType.CASCADE, 23, 0, PileType.OPEN, 1);
  //    game.move(PileType.CASCADE, 51, 0, PileType.OPEN, 2);
  //
  //    game.move(PileType.OPEN, 0, 0, PileType.CASCADE, 10);
  //
  //    assertEquals(expectedGameState, game.getGameState());
  //  }

  // test moving from foundation to open
  @Test
  public void testMove5() {
    String expectedGameState =
            "F1:\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1: A♠\n"
                    + "O2:\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1:\n"
                    + "C2: 2♠\n"
                    + "C3: 3♠\n"
                    + "C4: 4♠\n"
                    + "C5: 5♠\n"
                    + "C6: 6♠\n"
                    + "C7: 8♠\n"
                    + "C8: 7♠\n"
                    + "C9: 9♠\n"
                    + "C10: 10♠\n"
                    + "C11: J♠\n"
                    + "C12: Q♠\n"
                    + "C13: K♠\n"
                    + "C14: A♥\n"
                    + "C15: 2♥\n"
                    + "C16: 3♥\n"
                    + "C17: 4♥\n"
                    + "C18: 5♥\n"
                    + "C19: 6♥\n"
                    + "C20: 8♥\n"
                    + "C21: 7♥\n"
                    + "C22: 9♥\n"
                    + "C23: 10♥\n"
                    + "C24: J♥\n"
                    + "C25: Q♥\n"
                    + "C26: K♥\n"
                    + "C27: A♦\n"
                    + "C28: 2♦\n"
                    + "C29: 3♦\n"
                    + "C30: 4♦\n"
                    + "C31: 5♦\n"
                    + "C32: 6♦\n"
                    + "C33: 8♦\n"
                    + "C34: 7♦\n"
                    + "C35: 9♦\n"
                    + "C36: 10♦\n"
                    + "C37: J♦\n"
                    + "C38: Q♦\n"
                    + "C39: K♦\n"
                    + "C40: A♣\n"
                    + "C41: 2♣\n"
                    + "C42: 3♣\n"
                    + "C43: 4♣\n"
                    + "C44: 5♣\n"
                    + "C45: 6♣\n"
                    + "C46: 8♣\n"
                    + "C47: 7♣\n"
                    + "C48: 9♣\n"
                    + "C49: 10♣\n"
                    + "C50: J♣\n"
                    + "C51: Q♣\n"
                    + "C52: K♣";

    game.startGame(game.getDeck(), 52, 4, false);
    game.move(PileType.CASCADE, 0, 0, PileType.FOUNDATION, 0);
    game.move(PileType.FOUNDATION, 0, 0, PileType.OPEN, 0);
    assertEquals(expectedGameState, game.getGameState());
  }

  // test moving from open to open
  @Test
  public void testMove6() {
    String expectedGameState =
            "F1:\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1:\n"
                    + "O2: A♠\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1:\n"
                    + "C2: 2♠\n"
                    + "C3: 3♠\n"
                    + "C4: 4♠\n"
                    + "C5: 5♠\n"
                    + "C6: 6♠\n"
                    + "C7: 8♠\n"
                    + "C8: 7♠\n"
                    + "C9: 9♠\n"
                    + "C10: 10♠\n"
                    + "C11: J♠\n"
                    + "C12: Q♠\n"
                    + "C13: K♠\n"
                    + "C14: A♥\n"
                    + "C15: 2♥\n"
                    + "C16: 3♥\n"
                    + "C17: 4♥\n"
                    + "C18: 5♥\n"
                    + "C19: 6♥\n"
                    + "C20: 8♥\n"
                    + "C21: 7♥\n"
                    + "C22: 9♥\n"
                    + "C23: 10♥\n"
                    + "C24: J♥\n"
                    + "C25: Q♥\n"
                    + "C26: K♥\n"
                    + "C27: A♦\n"
                    + "C28: 2♦\n"
                    + "C29: 3♦\n"
                    + "C30: 4♦\n"
                    + "C31: 5♦\n"
                    + "C32: 6♦\n"
                    + "C33: 8♦\n"
                    + "C34: 7♦\n"
                    + "C35: 9♦\n"
                    + "C36: 10♦\n"
                    + "C37: J♦\n"
                    + "C38: Q♦\n"
                    + "C39: K♦\n"
                    + "C40: A♣\n"
                    + "C41: 2♣\n"
                    + "C42: 3♣\n"
                    + "C43: 4♣\n"
                    + "C44: 5♣\n"
                    + "C45: 6♣\n"
                    + "C46: 8♣\n"
                    + "C47: 7♣\n"
                    + "C48: 9♣\n"
                    + "C49: 10♣\n"
                    + "C50: J♣\n"
                    + "C51: Q♣\n"
                    + "C52: K♣";

    game.startGame(game.getDeck(), 52, 4, false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    game.move(PileType.OPEN, 0, 0, PileType.OPEN, 1);
    assertEquals(expectedGameState, game.getGameState());
  }

  //  // test moving from open to cascade
  //  @Test
  //  public void testMove7() {
  //    String expectedGameState =
  //            "F1:\n"
  //                    + "F2:\n"
  //                    + "F3:\n"
  //                    + "F4:\n"
  //                    + "O1:\n"
  //                    + "O2:\n"
  //                    + "O3:\n"
  //                    + "O4:\n"
  //                    + "C1: A♠\n"
  //                    + "C2: 2♠\n"
  //                    + "C3: 3♠\n"
  //                    + "C4: 4♠\n"
  //                    + "C5: 5♠\n"
  //                    + "C6: 6♠\n"
  //                    + "C7: 8♠\n"
  //                    + "C8: 7♠\n"
  //                    + "C9: 9♠\n"
  //                    + "C10: 10♠\n"
  //                    + "C11: J♠, 10♥\n"
  //                    + "C12: Q♠\n"
  //                    + "C13: K♠\n"
  //                    + "C14: A♥\n"
  //                    + "C15: 2♥\n"
  //                    + "C16: 3♥\n"
  //                    + "C17: 4♥\n"
  //                    + "C18: 5♥\n"
  //                    + "C19: 6♥\n"
  //                    + "C20: 8♥\n"
  //                    + "C21: 7♥\n"
  //                    + "C22: 9♥\n"
  //                    + "C23:\n"
  //                    + "C24: J♥\n"
  //                    + "C25: Q♥\n"
  //                    + "C26: K♥\n"
  //                    + "C27: A♦\n"
  //                    + "C28: 2♦\n"
  //                    + "C29: 3♦\n"
  //                    + "C30: 4♦\n"
  //                    + "C31: 5♦\n"
  //                    + "C32: 6♦\n"
  //                    + "C33: 8♦\n"
  //                    + "C34: 7♦\n"
  //                    + "C35: 9♦\n"
  //                    + "C36: 10♦\n"
  //                    + "C37: J♦\n"
  //                    + "C38: Q♦\n"
  //                    + "C39: K♦\n"
  //                    + "C40: A♣\n"
  //                    + "C41: 2♣\n"
  //                    + "C42: 3♣\n"
  //                    + "C43: 4♣\n"
  //                    + "C44: 5♣\n"
  //                    + "C45: 6♣\n"
  //                    + "C46: 8♣\n"
  //                    + "C47: 7♣\n"
  //                    + "C48: 9♣\n"
  //                    + "C49: 10♣\n"
  //                    + "C50: J♣\n"
  //                    + "C51: Q♣\n"
  //                    + "C52: K♣";
  //
  //    game.startGame(game.getDeck(), 52, 4, false);
  //    game.move(PileType.CASCADE, 22, 0, PileType.OPEN, 2);
  //    game.move(PileType.OPEN, 2, 0, PileType.CASCADE, 10);
  //    assertEquals(expectedGameState, game.getGameState());
  //  }

  // test moving from open to foundation
  @Test
  public void testMove8() {
    String expectedGameState =
            "F1: A♠\n"
                    + "F2: A♥\n"
                    + "F3: A♦\n"
                    + "F4: A♣\n"
                    + "O1:\n"
                    + "O2:\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1:\n"
                    + "C2: 2♠\n"
                    + "C3: 3♠\n"
                    + "C4: 4♠\n"
                    + "C5: 5♠\n"
                    + "C6: 6♠\n"
                    + "C7: 8♠\n"
                    + "C8: 7♠\n"
                    + "C9: 9♠\n"
                    + "C10: 10♠\n"
                    + "C11: J♠\n"
                    + "C12: Q♠\n"
                    + "C13: K♠\n"
                    + "C14:\n"
                    + "C15: 2♥\n"
                    + "C16: 3♥\n"
                    + "C17: 4♥\n"
                    + "C18: 5♥\n"
                    + "C19: 6♥\n"
                    + "C20: 8♥\n"
                    + "C21: 7♥\n"
                    + "C22: 9♥\n"
                    + "C23: 10♥\n"
                    + "C24: J♥\n"
                    + "C25: Q♥\n"
                    + "C26: K♥\n"
                    + "C27:\n"
                    + "C28: 2♦\n"
                    + "C29: 3♦\n"
                    + "C30: 4♦\n"
                    + "C31: 5♦\n"
                    + "C32: 6♦\n"
                    + "C33: 8♦\n"
                    + "C34: 7♦\n"
                    + "C35: 9♦\n"
                    + "C36: 10♦\n"
                    + "C37: J♦\n"
                    + "C38: Q♦\n"
                    + "C39: K♦\n"
                    + "C40:\n"
                    + "C41: 2♣\n"
                    + "C42: 3♣\n"
                    + "C43: 4♣\n"
                    + "C44: 5♣\n"
                    + "C45: 6♣\n"
                    + "C46: 8♣\n"
                    + "C47: 7♣\n"
                    + "C48: 9♣\n"
                    + "C49: 10♣\n"
                    + "C50: J♣\n"
                    + "C51: Q♣\n"
                    + "C52: K♣";

    game.startGame(game.getDeck(), 52, 4, false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    game.move(PileType.CASCADE, 13, 0, PileType.OPEN, 1);
    game.move(PileType.CASCADE, 26, 0, PileType.OPEN, 2);
    game.move(PileType.CASCADE, 39, 0, PileType.OPEN, 3);

    game.move(PileType.OPEN, 0, 0, PileType.FOUNDATION, 0);
    game.move(PileType.OPEN, 1, 0, PileType.FOUNDATION, 1);
    game.move(PileType.OPEN, 2, 0, PileType.FOUNDATION, 2);
    game.move(PileType.OPEN, 3, 0, PileType.FOUNDATION, 3);
    assertEquals(expectedGameState, game.getGameState());
  }

  // test move to foundation piles
  @Test
  public void testMove10() {
    String expectedGameState =
            "F1: A♣\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1: K♣\n"
                    + "O2: 8♣\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n"
                    + "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n"
                    + "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n"
                    + "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦\n"
                    + "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n"
                    + "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣";
    game.startGame(game.getDeck(), 6, 4, false);
    game.move(PileType.CASCADE, 3, 8, PileType.OPEN, 0);
    game.move(PileType.CASCADE, 3, 7, PileType.OPEN, 1);
    game.move(PileType.CASCADE, 3, 6, PileType.FOUNDATION, 0);

    game.move(PileType.FOUNDATION, 0, 0, PileType.FOUNDATION, 1);
    game.move(PileType.FOUNDATION, 1, 0, PileType.FOUNDATION, 2);
    game.move(PileType.FOUNDATION, 2, 0, PileType.FOUNDATION, 3);

    game.move(PileType.FOUNDATION, 3, 0, PileType.FOUNDATION, 2);
    game.move(PileType.FOUNDATION, 2, 0, PileType.FOUNDATION, 1);
    game.move(PileType.FOUNDATION, 1, 0, PileType.FOUNDATION, 0);
    assertEquals(expectedGameState, game.getGameState());
  }

  // test move to foundation piles
  @Test
  public void testWinGame() {
    String expectedGameState = "";
    game.startGame(game.getDeck(), 52, 4, false);

    game.move(PileType.CASCADE, 0, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 1, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 2, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 3, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 4, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 5, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 6, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 7, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 8, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 9, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 10, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 11, 0, PileType.FOUNDATION, 0);
    game.move(PileType.CASCADE, 12, 0, PileType.FOUNDATION, 0);

    game.move(PileType.CASCADE, 13, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 14, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 15, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 16, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 17, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 18, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 19, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 20, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 21, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 22, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 23, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 24, 0, PileType.FOUNDATION, 1);
    game.move(PileType.CASCADE, 25, 0, PileType.FOUNDATION, 1);

    game.move(PileType.CASCADE, 26, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 27, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 28, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 29, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 30, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 31, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 32, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 33, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 34, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 35, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 36, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 37, 0, PileType.FOUNDATION, 2);
    game.move(PileType.CASCADE, 38, 0, PileType.FOUNDATION, 2);

    game.move(PileType.CASCADE, 39, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 40, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 41, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 42, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 43, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 44, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 45, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 46, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 47, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 48, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 49, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 50, 0, PileType.FOUNDATION, 3);
    game.move(PileType.CASCADE, 51, 0, PileType.FOUNDATION, 3);

    assertEquals(true, game.isGameOver());
  }

  // moving wrong cascade card
  @Test(expected = IllegalArgumentException.class)
  public void testMoveWrongCard() {
    game.startGame(game.getDeck(), 6, 4, false);
    game.move(PileType.CASCADE, 0, 0, PileType.FOUNDATION, 0);
  }

  // moving from foundation to foundation
  @Test(expected = IllegalArgumentException.class)
  public void testCantDoThis() {
    game.startGame(game.getDeck(), 6, 4, false);
    game.move(PileType.CASCADE, 5, 0, PileType.FOUNDATION, 0);
  }

  // invalid cascade size
  @Test(expected = IllegalArgumentException.class)
  public void testCascadeSize() {
    game.startGame(game.getDeck(), 3, 4, false);
  }

  // test to verify that move throws an IllegalArgumentException
  // when a card is moved to an open pile that already contains a card
  @Test(expected = IllegalArgumentException.class)
  public void testFullOpenPile() {
    game.startGame(game.getDeck(), 52, 4, false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    game.move(PileType.CASCADE, 1, 0, PileType.OPEN, 0);
  }
}