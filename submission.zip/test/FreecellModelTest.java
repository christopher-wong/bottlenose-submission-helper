/**
 * Created by cWong on 1/24/17.
 */

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.PileType;
import cs3500.hw02.Suit;
import cs3500.hw02.Value;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class FreecellModelTest {
  private FreecellModel game;
  private List<Card> validDeck;
  private List<Card> tooLargeDeck;
  private String validDeckString;

  /**
   * This method sets up test variables.
   */
  @Before
  public void setUp() throws Exception {
    game = new FreecellModel();
    validDeck = game.getDeck();

    List<Card> duplicateDeck;
    duplicateDeck = game.getDeck();
    duplicateDeck.set(1, new Card(Value.JACK, Suit.SPADE));

    tooLargeDeck = game.getDeck();
    tooLargeDeck.add(new Card(Value.EIGHT, Suit.HEART));
    tooLargeDeck.add(new Card(Value.EIGHT, Suit.HEART));
    tooLargeDeck.add(new Card(Value.EIGHT, Suit.HEART));
    tooLargeDeck.add(new Card(Value.EIGHT, Suit.HEART));

    validDeckString = "[A♠, 2♠, 3♠, 4♠, 5♠, 6♠, 8♠, 7♠, 9♠, 10♠, J♠, Q♠, K♠, "
            + "A♥, 2♥, 3♥, 4♥, 5♥, 6♥, 8♥, 7♥, 9♥, 10♥, J♥, Q♥, K♥, "
            + "A♦, 2♦, 3♦, 4♦, 5♦, 6♦, 8♦, 7♦, 9♦, 10♦, J♦, Q♦, K♦, "
            + "A♣, 2♣, 3♣, 4♣, 5♣, 6♣, 8♣, 7♣, 9♣, 10♣, J♣, Q♣, K♣]";
  }

  // test that deck has 52 cards
  @Test
  public void testDeckSize() {
    assertEquals(validDeck.size(), 52);
  }

  // test that deck has all expected cards
  @Test
  public void testDeckContents() {
    assertEquals(validDeck.toString(), validDeckString);
  }

  // test gameOver
  @Test
  public void testIsGameOver() {
    game.startGame(game.getDeck(), 8, 4, false);
    assertEquals(false, game.isGameOver());
  }

  // check that initial, non-shuffled game, prints properly
  @Test
  public void testGetGameState() {
    game.startGame(game.getDeck(), 8, 4, false);

    String expectedGameState =
            "F1:\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1:\n"
                    + "O2:\n"
                    + "O3:\n"
                    + "O4:\n"
                    + "C1: A♠, 9♠, 4♥, Q♥, 8♦, 2♣, 10♣\n"
                    + "C2: 2♠, 10♠, 5♥, K♥, 7♦, 3♣, J♣\n"
                    + "C3: 3♠, J♠, 6♥, A♦, 9♦, 4♣, Q♣\n"
                    + "C4: 4♠, Q♠, 8♥, 2♦, 10♦, 5♣, K♣\n"
                    + "C5: 5♠, K♠, 7♥, 3♦, J♦, 6♣\n"
                    + "C6: 6♠, A♥, 9♥, 4♦, Q♦, 8♣\n"
                    + "C7: 8♠, 2♥, 10♥, 5♦, K♦, 7♣\n"
                    + "C8: 7♠, 3♥, J♥, 6♦, A♣, 9♣";

    assertEquals(expectedGameState, game.getGameState());
  }

  // check exception from deck with too many cards
  @Test(expected = IllegalArgumentException.class)
  public void testTooLargeDeck() {
    game.validateDeck(tooLargeDeck);
  }

  // check number of cascade piles
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCascadePilesCount() {
    game.startGame(game.getDeck(), 0, 4, false);
    game.startGame(game.getDeck(), 53, 4, false);
  }

  // check number of open piles
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidOpenPilesCount() {
    game.startGame(game.getDeck(), 8, 0, false);
    game.startGame(game.getDeck(), 8, 53, false);
  }

  // test getGameState returning an empty string when game has not begun
  @Test
  public void testGetGameState_noGame() {
    assertEquals("", game.getGameState());
  }

  // test doubleDeal
  @Test
  public void testDoubleDeal() {
    FreecellModel game = new FreecellModel();
    List<Card> deck = game.getDeck();

    game.startGame(deck, 4, 2, false);
    String state1 = game.getGameState();

    game.startGame(deck, 4, 2, false);
    String state2 = game.getGameState();

    assertEquals(state1, state2);
  }

  // test nullDeck
  @Test(expected = NullPointerException.class)
  public void testNullDeck() {
    game.startGame(null, 8, 0,
            false);
  }

  // test shuffle
  @Test
  public void testShuffle() {
    FreecellModel game = new FreecellModel();
    List<Card> deck = game.getDeck();

    game.startGame(deck, 4, 2, false);
    String state1 = game.getGameState();

    game.startGame(deck, 4, 2, true);
    String state2 = game.getGameState();

    assertNotEquals(state1, state2);
  }

  // move to empty open
  @Test
  public void moveToEmptyOpen() {
    game.startGame(game.getDeck(), 52, 4,
            false);

    // foundation to open
    game.move(PileType.CASCADE, 0, 0, PileType.FOUNDATION, 0);
    game.move(PileType.FOUNDATION, 0, 0, PileType.OPEN, 0);

    // open to open
    game.move(PileType.CASCADE, 10, 0, PileType.OPEN, 1);
    game.move(PileType.OPEN, 1, 0, PileType.OPEN, 2);

    assertEquals("F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: A♠\n" +
            "O2:\n" +
            "O3: J♠\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11:\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣", game.getGameState());
  }

}

