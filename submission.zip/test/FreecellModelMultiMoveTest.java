import org.junit.Before;
import org.junit.Test;

import java.io.StringReader;
import java.io.StringWriter;

import cs3500.hw02.FreecellOperations;
import cs3500.hw03.FreecellController;
import cs3500.hw04.FreecellModelCreator;

import static org.junit.Assert.assertEquals;

/**
 * Created by cWong on 2/14/17.
 */
public class FreecellModelMultiMoveTest {
  FreecellModelCreator creator;
  FreecellOperations model;
  Appendable writer;
  FreecellController controller;

  /**
   * Sets up test variables
   *
   * @throws Exception if setup fails.
   */
  @Before
  public void setUp() throws Exception {
    creator = new FreecellModelCreator();
    model = FreecellModelCreator.create(FreecellModelCreator.GameType.MULTIMOVE);
    writer = new StringWriter();
  }

  @Test
  public void validMove_test1() {
    String input = "C25 1 C52 " +
            "C11 1 C52 " +
            "C36 1 C52 " +
            "C9 1 C52 " +
            "C52 2 C25 q";
    controller = new FreecellController(new StringReader(input), writer);

    controller.playGame(model.getDeck(), model, 52, 4, false);

    assertEquals(true, writer.toString().contains("C25: Q♥, J♠, 10♦, 9♠"));
  }

  @Test
  public void validMove_test2() {
    String input = "C4 9 O1 C4 8 O2 C5 8 O3 C4 C4 7 F2 C5 7 F2 C6 8 O4 C6 7 F2 O2 1 C5 q";
    controller = new FreecellController(new StringReader(input), writer);

    controller.playGame(model.getDeck(), model, 6, 4, false);

    assertEquals("\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2: 8♣\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2: 8♣\n" +
            "O3: 7♣\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Invalid Card Number, Try again: Destination Pile (e.g. F1): F1:\n" +
            "F2: A♣\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2: 8♣\n" +
            "O3: 7♣\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2: A♣, 2♣\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2: 8♣\n" +
            "O3: 7♣\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2: A♣, 2♣\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2: 8♣\n" +
            "O3: 7♣\n" +
            "O4: 9♣\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2: A♣, 2♣, 3♣\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2: 8♣\n" +
            "O3: 7♣\n" +
            "O4: 9♣\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2: A♣, 2♣, 3♣\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: K♣\n" +
            "O2:\n" +
            "O3: 7♣\n" +
            "O4: 9♣\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 8♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void invalidMove_illegalBuild() {
    String input = "C1 5 C2 q";
    controller = new FreecellController(new StringReader(input), writer);

    controller.playGame(model.getDeck(), model, 6, 4, false);

    assertEquals(true, writer.toString().contains(
            "Error: Can't move, invalid build! Try again:"));
  }
}
