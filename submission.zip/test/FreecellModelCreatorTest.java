import org.junit.Before;
import org.junit.Test;

import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;
import cs3500.hw04.FreecellModelCreator;

import static org.junit.Assert.assertEquals;

/**
 * Created by cWong on 2/3/17.
 * Restructured tests to use setup and teardown for flexiblity and reduced code duplication
 */
public class FreecellModelCreatorTest {
  FreecellOperations model;
  FreecellModelCreator creator;

  /**
   * This method sets up test variables.
   *
   * @throws Exception if setup is not executed properly
   */
  @Before
  public void setUp() throws Exception {
    creator = new FreecellModelCreator();
  }

  /**
   * This method tears down test variables.
   *
   * @throws Exception if setup is not executed properly
   */
  @Before
  public void tearDown() throws Exception {
    model = null;
  }

  @Test
  public void testCreateSingle() {
    model = FreecellModelCreator.create(FreecellModelCreator.GameType.SINGLEMOVE);
    assertEquals(true, model instanceof FreecellModel);
  }

  @Test
  public void testCreateMulti() {
    model = FreecellModelCreator.create(FreecellModelCreator.GameType.SINGLEMOVE);
    assertEquals(true, model instanceof FreecellModel);
  }
}