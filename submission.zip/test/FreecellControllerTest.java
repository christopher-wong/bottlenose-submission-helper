import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.StringReader;
import java.io.StringWriter;

import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;
import cs3500.hw03.FreecellController;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Created by cWong on 2/3/17.
 * Restructured tests to use setup and teardown for flexiblity and reduced code duplication
 */
public class FreecellControllerTest {
  FreecellOperations model;
  Appendable writer;

  String badDestPileOutput = "Enter number of Cascade Piles: " +
          "Enter number of Open Piles: Do you want to shuffle (y/n): \n" +
          "# Cascade Piles: 6\n" +
          "# Open Piles: 4\n" +
          "Deck in order!\n" +
          "\n" +
          "F1:\n" +
          "F2:\n" +
          "F3:\n" +
          "F4:\n" +
          "O1:\n" +
          "O2:\n" +
          "O3:\n" +
          "O4:\n" +
          "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
          "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
          "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
          "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
          "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
          "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
          "\n" +
          "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): " +
          "Invalid Pile Input, Try again: \n" +
          "Game quit prematurely.";
  String badSourcePileOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
          "Do you want to shuffle (y/n): \n" +
          "# Cascade Piles: 6\n" +
          "# Open Piles: 4\n" +
          "Deck in order!\n" +
          "\n" +
          "F1:\n" +
          "F2:\n" +
          "F3:\n" +
          "F4:\n" +
          "O1:\n" +
          "O2:\n" +
          "O3:\n" +
          "O4:\n" +
          "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
          "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
          "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
          "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
          "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
          "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
          "\n" +
          "Source Pile (e.g. C1): Invalid Pile Input, Try again: \n" +
          "Game quit prematurely.";

  /**
   * This method sets up test variables.
   *
   * @throws Exception if setup is not executed properly
   */
  @Before
  public void setUp() throws Exception {
    model = new FreecellModel();
    writer = new StringWriter();
  }

  /**
   * This method tears down test variables.
   *
   * @throws Exception if setup is not executed properly
   */
  @After
  public void tearDown() throws Exception {
    model = null;
    writer = null;
  }

  @Test
  public void goodCascadeToCascade() {
    String input = "52 4 n C23 1 C50 q";
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23:\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣, 10♥\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodCascadeToOpen() {
    String input = "52 4 n C23 1 O1 q";

    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♥\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23:\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodCascadeToFoundation() {
    String input = "52 4 n C1 1 F1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1: A♠\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodOpenToFoundation() {
    String input = "52 4 n C1 1 O1 O1 1 F1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: A♠\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1: A♠\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodOpenToOpen() {
    String input = "52 4 n C1 1 O1 O1 1 F2 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: A♠\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2: A♠\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodOpenToCascade() {
    String input = "52 4 n C1 1 O1 O1 1 C1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: A♠\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodFoundationtoFoundation() {
    String input = "52 4 n C1 1 F1 F1 1 F2 F2 1 F3 F3 1 F4 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1: A♠\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2: A♠\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3: A♠\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4: A♠\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodFoundationToOpen() {
    String input = "52 4 n C1 1 F1 F1 1 O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1: A♠\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: A♠\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void goodFoundationToCascade() {
    String input = "52 4 n C1 1 F1 F1 1 C1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1: A♠\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void shuffleVsNoShuffle() {
    String input = "6 4 n q";
    Appendable writerShuffle = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writerShuffle);
    controller.initController();

    input = "6 4 n q";
    Appendable writerNoShuffle = new StringWriter();
    controller = new FreecellController(new StringReader(input), writerShuffle);
    controller.initController();


    assertNotEquals(writerNoShuffle, writerShuffle);
  }

  @Test
  public void quitGameSourcePileLowerCase() {
    model = new FreecellModel();
    String input = "6 4 n q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    String sampleOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.";

    assertEquals(sampleOutput, writer.toString());
  }

  @Test
  public void quitGameCardIndexLowerCase() {
    model = new FreecellModel();
    String input = "6 4 n C1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    String sampleOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): \n" +
            "Game quit prematurely.";

    assertEquals(sampleOutput, writer.toString());
  }

  @Test
  public void quitGameDestPileLowerCase() {
    model = new FreecellModel();
    String input = "6 4 n C1 5 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    String sampleOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Game quit prematurely.";

    assertEquals(sampleOutput, writer.toString());
  }

  @Test
  public void quitGameSourcePileUpperCase() {
    model = new FreecellModel();
    String input = "6 4 n Q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    String sampleOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.";

    assertEquals(sampleOutput, writer.toString());
  }

  @Test
  public void quitGameCardIndexUpperCase() {
    model = new FreecellModel();
    String input = "6 4 n C1 Q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    String sampleOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): \n" +
            "Game quit prematurely.";

    assertEquals(sampleOutput, writer.toString());
  }

  @Test
  public void quitGameDestPileUpperCase() {
    model = new FreecellModel();
    String input = "6 4 n C1 5 Q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    String sampleOutput = "Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Game quit prematurely.";

    assertEquals(sampleOutput, writer.toString());
  }

  @Test
  public void badSourcePile_1() {
    model = new FreecellModel();
    String input = "6 4 n A q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badSourcePile_2() {
    model = new FreecellModel();
    String input = "6 4 n A- q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badSourcePile_3() {
    model = new FreecellModel();
    String input = "6 4 n A-2 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badSourcePile_4() {
    model = new FreecellModel();
    String input = "6 4 n A-200000 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badSourcePile_5() {
    model = new FreecellModel();
    String input = "6 4 n 1234 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badSourcePile_6() {
    model = new FreecellModel();
    String input = "6 4 n .. q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badSourcePile_7() {
    model = new FreecellModel();
    String input = "6 4 n [ q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badSourcePileOutput, writer.toString());
  }

  @Test
  public void badDestPile_1() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 A q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badDestPile_2() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 A- q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badDestPile_3() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 A-2 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badDestPile_4() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 A-200000 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badDestPile_5() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 1234 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badDestPile_6() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 .. q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badDestPile_7() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 [ q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(badDestPileOutput, writer.toString());
  }

  @Test
  public void badOpenToFoundation() {
    model = new FreecellModel();
    String input = "6 4 n O1 9 F1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badFoundationToOpen() {
    model = new FreecellModel();
    String input = "6 4 n F1 9 O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToFullOpen() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 O1 C1 8 O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Open pile is full! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badOpenToFullOpen() {
    String input = "6 4 n C1 9 O1 C1 8 O2 O1 1 O2 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2: 4♣\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Open pile is full! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2: 4♣\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToOpen_1() {
    model = new FreecellModel();
    String input = "6 4 n C1 1 O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToOpen_2() {
    model = new FreecellModel();
    String input = "6 4 n C1 9 O1 C2 9 O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Open pile is full! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToFoundation_1() {
    model = new FreecellModel();
    String input = "6 4 n C6 9 F4 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToFoundation_2() {
    model = new FreecellModel();
    String input = "6 4 n C1 1 F1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 6\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠, 8♠, K♠, 6♥, Q♥, 5♦, J♦, 4♣, 10♣\n" +
            "C2: 2♠, 7♠, A♥, 8♥, K♥, 6♦, Q♦, 5♣, J♣\n" +
            "C3: 3♠, 9♠, 2♥, 7♥, A♦, 8♦, K♦, 6♣, Q♣\n" +
            "C4: 4♠, 10♠, 3♥, 9♥, 2♦, 7♦, A♣, 8♣, K♣\n" +
            "C5: 5♠, J♠, 4♥, 10♥, 3♦, 9♦, 2♣, 7♣\n" +
            "C6: 6♠, Q♠, 5♥, J♥, 4♦, 10♦, 3♣, 9♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToCascade_1() {
    model = new FreecellModel();
    String input = "52 4 n C1 1 C2 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToCascade_2() {
    model = new FreecellModel();
    String input = "52 4 n C1 1 C7 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: Cannot move this card! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void badCascadeToFoundation() {
    model = new FreecellModel();
    String input = "52 4 n C5 1 F1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): \n" +
            "Error: First card in foundation must be ace! Try again: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test
  public void winGame() {
    model = new FreecellModel();
    String input = "52 4 n " +
            "C1 1 F1 " + "C14 1 F2 " + "C27 1 F3 " + "C40 1 F4 " +
            "C2 1 F1 " + "C15 1 F2 " + "C28 1 F3 " + "C41 1 F4 " +
            "C3 1 F1 " + "C16 1 F2 " + "C29 1 F3 " + "C42 1 F4 " +
            "C4 1 F1 " + "C17 1 F2 " + "C30 1 F3 " + "C43 1 F4 " +
            "C5 1 F1 " + "C18 1 F2 " + "C31 1 F3 " + "C44 1 F4 " +
            "C6 1 F1 " + "C19 1 F2 " + "C32 1 F3 " + "C45 1 F4 " +
            "C7 1 F1 " + "C20 1 F2 " + "C33 1 F3 " + "C46 1 F4 " +
            "C8 1 F1 " + "C21 1 F2 " + "C34 1 F3 " + "C47 1 F4 " +
            "C9 1 F1 " + "C22 1 F2 " + "C35 1 F3 " + "C48 1 F4 " +
            "C10 1 F1 " + "C23 1 F2 " + "C36 1 F3 " + "C49 1 F4 " +
            "C11 1 F1 " + "C24 1 F2 " + "C37 1 F3 " + "C50 1 F4 " +
            "C12 1 F1 " + "C25 1 F2 " + "C38 1 F3 " + "C51 1 F4 " +
            "C13 1 F1 " + "C26 1 F2 " + "C39 1 F3 " + "C52 1 F4";

    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(true, writer.toString().contains("\n" + "Game over."));
  }

  @Test
  public void weirdGame() {
    model = new FreecellModel();
    String input = "52 4 n C40 1 F4 " +
            "C41 1 F4 " +
            "C42 1 F4 q";

    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals("Enter number of Cascade Piles: Enter number of Open Piles: " +
            "Do you want to shuffle (y/n): \n" +
            "# Cascade Piles: 52\n" +
            "# Open Piles: 4\n" +
            "Deck in order!\n" +
            "\n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40: A♣\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4: A♣\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40:\n" +
            "C41: 2♣\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4: A♣, 2♣\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40:\n" +
            "C41:\n" +
            "C42: 3♣\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): Card Number (e.g.): Destination Pile (e.g. F1): F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4: A♣, 2♣, 3♣\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♠\n" +
            "C2: 2♠\n" +
            "C3: 3♠\n" +
            "C4: 4♠\n" +
            "C5: 5♠\n" +
            "C6: 6♠\n" +
            "C7: 8♠\n" +
            "C8: 7♠\n" +
            "C9: 9♠\n" +
            "C10: 10♠\n" +
            "C11: J♠\n" +
            "C12: Q♠\n" +
            "C13: K♠\n" +
            "C14: A♥\n" +
            "C15: 2♥\n" +
            "C16: 3♥\n" +
            "C17: 4♥\n" +
            "C18: 5♥\n" +
            "C19: 6♥\n" +
            "C20: 8♥\n" +
            "C21: 7♥\n" +
            "C22: 9♥\n" +
            "C23: 10♥\n" +
            "C24: J♥\n" +
            "C25: Q♥\n" +
            "C26: K♥\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "C30: 4♦\n" +
            "C31: 5♦\n" +
            "C32: 6♦\n" +
            "C33: 8♦\n" +
            "C34: 7♦\n" +
            "C35: 9♦\n" +
            "C36: 10♦\n" +
            "C37: J♦\n" +
            "C38: Q♦\n" +
            "C39: K♦\n" +
            "C40:\n" +
            "C41:\n" +
            "C42:\n" +
            "C43: 4♣\n" +
            "C44: 5♣\n" +
            "C45: 6♣\n" +
            "C46: 8♣\n" +
            "C47: 7♣\n" +
            "C48: 9♣\n" +
            "C49: 10♣\n" +
            "C50: J♣\n" +
            "C51: Q♣\n" +
            "C52: K♣\n" +
            "\n" +
            "Source Pile (e.g. C1): \n" +
            "Game quit prematurely.", writer.toString());
  }

  @Test(expected = IllegalStateException.class)
  public void testNullReadable() {
    Appendable writer = new StringWriter();

    FreecellController controller = new FreecellController(null, writer);
  }

  @Test(expected = IllegalStateException.class)
  public void testNullAppendable() {
    String input = "";

    FreecellController controller = new FreecellController(new StringReader(input), null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullDeck() {
    model = new FreecellModel();
    Appendable writer = new StringWriter();

    String input = "";

    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.playGame(null, model, 6, 5, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullModel() {
    model = new FreecellModel();
    Appendable writer = new StringWriter();

    String input = "";

    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.playGame(model.getDeck(), null, 6, 5, false);
  }

  @Test
  public void badCardIndex_1() {
    model = new FreecellModel();
    String input = "6 4 n " +
            "C1 g O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(true, writer.toString().contains("Invalid Card Number, Try again: "));
  }

  @Test
  public void badCardIndex_2() {
    model = new FreecellModel();
    String input = "6 4 n " +
            "C1 -9 O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(true, writer.toString().contains("Invalid Card Number, Try again: "));
  }

  @Test
  public void badCardIndex_3() {
    model = new FreecellModel();
    String input = "6 4 n " +
            "C1 .. O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(true, writer.toString().contains("Invalid Card Number, Try again: "));
  }

  @Test
  public void badCardIndex_4() {
    model = new FreecellModel();
    String input = "6 4 n " +
            "C1 AAA O1 q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(true, writer.toString().contains("Invalid Card Number, Try again: "));
  }

  @Test
  public void couldNotStartGame() {
    model = new FreecellModel();
    String input = "1 1 n q";
    Appendable writer = new StringWriter();
    FreecellController controller = new FreecellController(new StringReader(input), writer);
    controller.initController();

    assertEquals(true, writer.toString().contains("Could not start game."));
  }
}
