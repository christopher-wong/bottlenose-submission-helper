package cs3500.hw02;

/**
 * Created by cWong on 1/24/17.
 */
public enum Value {
  ACE(1),
  TWO(2),
  THREE(3),
  FOUR(4),
  FIVE(5),
  SIX(6),
  EIGHT(8),
  SEVEN(7),
  NINE(9),
  TEN(10),
  JACK(11),
  QUEEN(12),
  KING(13);

  // representing a card's numerical value
  private final int value;

  /**
   * initialize value of card.
   */
  Value(int value) {
    this.value = value;
  }

  /**
   * @return value as int.
   */
  public int toInt() {
    return this.value;
  }

  /**
   * @return either card symbol or numerical values.
   */
  public String toString() {
    StringBuilder output = new StringBuilder();
    switch (this) {
      case ACE:
        return "A";
      case JACK:
        return "J";
      case QUEEN:
        return "Q";
      case KING:
        return "K";
      default:
        return String.format("%d", value);
    }
  }
}
