package cs3500.hw02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by cWong on 1/22/17.
 */

/**
 * This class represents an instance of a FreecellModel.
 */
public class FreecellModel implements FreecellOperations<Card> {
  protected ArrayList<ArrayList<Card>> cascadePiles;
  protected ArrayList<ArrayList<Card>> foundationPiles;
  protected ArrayList<ArrayList<Card>> openPiles;

  /**
   * Suit order ♠ ♥ ♦ ♣.
   *
   * @return a deck of 52 cards, no jokers, in ascending order.
   */
  @Override
  public List<Card> getDeck() {
    List<Card> deck = new ArrayList<Card>(52);
    int cardsInSuit = 13;

    Value[] value = Value.values();
    Suit[] suit = Suit.values();

    // add spades to deck
    for (int i = 0; i < cardsInSuit; i++) {
      Card c = new Card(value[i], suit[0]);
      deck.add(c);
    }

    // add hearts to deck
    for (int i = 0; i < cardsInSuit; i++) {
      Card c = new Card(value[i], suit[1]);
      deck.add(c);
    }

    // add diamonds to deck
    for (int i = 0; i < cardsInSuit; i++) {
      Card c = new Card(value[i], suit[2]);
      deck.add(c);
    }

    // add clubs to deck
    for (int i = 0; i < cardsInSuit; i++) {
      Card c = new Card(value[i], suit[3]);
      deck.add(c);
    }

    return deck;
  }

  /**
   * This method validates that a deck has no duplicates and that it has 52 cards.
   *
   * @param deck Validate that the deck is valid.
   */
  public void validateDeck(List<Card> deck) {
    Set<Card> set = new HashSet<Card>(deck);

    if (set.size() < deck.size()) {
      throw new IllegalArgumentException("Duplicates exist!");
    }

    // check deck size is exactly 52 cards
    if (deck.size() != 52) {
      throw new IllegalArgumentException("Deck has too many cards!!");
    }
  }

  /**
   * Takes a pile type and gives the variable name.
   *
   * @param pile type.
   * @return name of pile variable.
   */
  // made changes here to reduce code duplication and increase abstraction
  protected List<ArrayList<Card>> pileConvert(PileType pile) {
    switch (pile) {
      case CASCADE:
        return cascadePiles;
      case OPEN:
        return openPiles;
      case FOUNDATION:
        return foundationPiles;
      default:
        throw new IllegalArgumentException("Pile type not valid!");
    }
  }

  /**
   * This method validates that all inputs for startGame fall within expected ranges.
   *
   * @param deck            To be verified.
   * @param numCascadePiles To be verified.
   * @param numOpenPiles    To be verified.
   */
  private void validateGameInputs(List<Card> deck, int numCascadePiles, int numOpenPiles) {
    validateDeck(deck);

    if (deck == null) {
      throw new NullPointerException("Null deck!");
    }

    // check that numCascadePiles is in range
    if (numCascadePiles < 4 || numCascadePiles > 52) {
      throw new IllegalArgumentException("Number of cascade piles is invalid!");
    }

    // check that numOpenPiles is in range
    if (numOpenPiles < 1 || numOpenPiles > 52) {
      throw new IllegalArgumentException("Number of open piles is invalid!");
    }
  }

  /**
   * @param deck            the deck to be dealt.
   * @param numCascadePiles there can be a maximum of 52 cascade piles
   * @param numOpenPiles    number of open piles.
   * @param shuffle         if true, shuffle the deck else deal the deck as-is.
   * @throws IllegalArgumentException if params are invalid.
   */
  @Override
  public void startGame(List<Card> deck, int numCascadePiles, int numOpenPiles, boolean shuffle)
          throws IllegalArgumentException {

    // check that game inputs are valid
    validateGameInputs(deck, numCascadePiles, numOpenPiles);

    cascadePiles = new ArrayList<ArrayList<Card>>();
    foundationPiles = new ArrayList<ArrayList<Card>>();
    openPiles = new ArrayList<ArrayList<Card>>();

    // should I shuffle?
    if (shuffle) {
      // use fisher-yates shuffle from Collections
      Collections.shuffle(deck);
    }

    for (int i = 0; i < 4; i++) {
      foundationPiles.add(new ArrayList<Card>());
    }
    for (int i = 0; i < numCascadePiles; i++) {
      cascadePiles.add(new ArrayList<Card>());
    }
    for (int i = 0; i < numOpenPiles; i++) {
      openPiles.add(new ArrayList<Card>());
    }

    for (int i = 0; i < deck.size(); i++) {
      Card card = deck.get(i);
      cascadePiles.get(i % numCascadePiles).add(card);
    }
  }

  /**
   * This method helps abstract the adding and removing of a card between piles.
   *
   * @param fromPile       The pile from which a card is being taken.
   * @param toPile         The pile which the card is getting added to.
   * @param cardIndex      The card being picked.
   * @param pileNumber     The pile which the card is being picked from.
   * @param destPileNumber THe pile which the card is being added to.
   */
  protected void addRemoveCard(ArrayList<Card> fromPile, ArrayList<Card> toPile, int cardIndex,
                               int pileNumber, int destPileNumber) throws IllegalArgumentException {

    if (cardIndex > fromPile.size() - 1) {
      throw new IllegalArgumentException("Pile size invalid");
    }

    Card cardToMove = fromPile.get(cardIndex);
    // add card to destination pile
    toPile.add(cardToMove);
    // delete card from source pile
    fromPile.remove(cardToMove);
  }

  /**
   * @param pile  Read in type of pile.
   * @param index Read in index of pile trying to be accessed.
   */
  protected void doesPileExist(PileType pile, int index) {
    if (index > pileConvert(pile).size() - 1) {
      throw new IllegalArgumentException(pile.toFullString() + " pile does not exist");
    }
  }

  /**
   * Validate that card index is valid
   *
   * @param source    Read in the type of pile.
   * @param pileIndex The pile where the card exists.
   * @param cardIndex The card you want to move.
   */
  // made changes here to reduce code duplication and increase abstraction
  protected void validCardIndex(PileType source, int pileIndex, int
          cardIndex) {

    if (cardIndex < 0 || cardIndex != pileConvert(source).get(pileIndex).size() - 1) {
      throw new IllegalArgumentException("Cannot move this card!");
    }
  }

  /**
   * Validate that a move to a cascade pile is legal.
   *
   * @param source         Input pile from the user.
   * @param pileNumber     Pile number from the user.
   * @param destPileNumber Destination pile number from the user.
   * @param cardIndex      Card index from the user.
   */
  protected void validateMoveToCascade(PileType source, PileType destination, int pileNumber, int
          destPileNumber, int cardIndex) {

    int lastCardIndex = pileConvert(source).get(destPileNumber).size() - 1;

    if (pileConvert(source).get(destPileNumber).size() == 0
            && pileConvert(source).get(pileNumber).get(cardIndex).getValue() == 13) {
      throw new IllegalArgumentException("Cannot add King to empty cascade pile!");
    }

    if (pileConvert(source).get(pileNumber).get(cardIndex).getColor().equals(
            pileConvert(destination).get(destPileNumber).get(lastCardIndex).getColor())

            || pileConvert(source).get(pileNumber).get(cardIndex).getValue()
            + 1 != pileConvert(destination).get(destPileNumber).get(lastCardIndex).getValue()) {
      throw new IllegalArgumentException("Cannot move this card!");
    }
  }

  /**
   * Validate moving first card to foundation pile is valid
   *
   * @param pile           Input pile from the user.
   * @param pileNumber     Pile number from the user.
   * @param destPileNumber Destination pile number from the user.
   * @param cardIndex      Card index from the user.
   */
  protected void validateFoundationFirstCard(PileType pile, int pileNumber, int destPileNumber,
                                             int cardIndex) {

    if (foundationPiles.get(destPileNumber).size() == 0
            && pileConvert(pile).get(pileNumber).get(cardIndex).getValue() > 1) {
      throw new IllegalArgumentException("First card in foundation must be ace!");
    }
  }

  /**
   * Validate that a move to a foundation pile is legal.
   *
   * @param pile           Input pile from the user.
   * @param pileNumber     Pile number from the user.
   * @param destPileNumber Destination pile number from the user.
   * @param cardIndex      Card index from the user.
   */
  protected void validateMoveToFoundation(PileType pile, int pileNumber, int destPileNumber,
                                          int cardIndex) {

    int lastSourceCardIdx = pileConvert(pile).get(pileNumber).size() - 1;
    int lastDestCardIdx = foundationPiles.get(destPileNumber).size() - 1;
    String sourceColor;
    String destColor;
    int sourceValue;
    int destValue;

    if (lastSourceCardIdx < 0) {
      return;
    }

    switch (pile) {
      case CASCADE:
        lastSourceCardIdx = cascadePiles.get(destPileNumber).size() - 1;
        if (lastSourceCardIdx < 0) {
          return;
        }

        sourceColor = cascadePiles.get(pileNumber).get(cardIndex).getColor();
        destColor = foundationPiles.get(destPileNumber).get(lastDestCardIdx).getColor();

        sourceValue = cascadePiles.get(pileNumber).get(cardIndex).getValue();
        destValue = foundationPiles.get(destPileNumber).get(lastDestCardIdx).getValue();

        if (!sourceColor.equals(destColor) || sourceValue != destValue + 1) {
          throw new IllegalArgumentException("Cannot move card from " + pile.toFullString()
                  + " to foundation!");
        }
        break;
      default:
        break;
    }

    sourceColor = pileConvert(pile).get(pileNumber).get(cardIndex).getColor();
    destColor = foundationPiles.get(destPileNumber).get(lastDestCardIdx).getColor();

    sourceValue = pileConvert(pile).get(pileNumber).get(cardIndex).getValue();
    destValue = foundationPiles.get(destPileNumber).get(lastDestCardIdx).getValue();

    if (!sourceColor.equals(destColor) || sourceValue != destValue + 1) {
      throw new IllegalArgumentException("Cannot move card from open to foundation!");
    }
  }

  @Override
  public void move(PileType source, int pileNumber, int cardIndex, PileType destination,
                   int destPileNumber) throws IllegalArgumentException {

    // if piles are null
    if (foundationPiles == null || cascadePiles == null || openPiles == null) {
      throw new IllegalArgumentException("Game has not started!");
    }

    // if game is over
    if (isGameOver()) {
      throw new IllegalArgumentException("Game is over!");
    }

    // if inputs are negative
    if (pileNumber < 0 || cardIndex < 0 || destPileNumber < 0) {
      throw new IllegalArgumentException("Inputs are negative!");
    }

    // does source pile exist?
    doesPileExist(source, pileNumber);

    // does dest pile exist?
    doesPileExist(destination, destPileNumber);

    // only allowed to move last card in cascade pile or foundation pile
    validCardIndex(source, pileNumber, cardIndex);

    // if open piles are full
    if (destination == PileType.OPEN && openPiles.get(destPileNumber).size() >= 1) {
      throw new IllegalArgumentException("Open pile is full!");
    }

    // if moving to cascade pile, make sure suits are different and card is 1 less in value
    if (destination == PileType.CASCADE && cascadePiles.get(destPileNumber).size() > 0) {
      validateMoveToCascade(source, destination, pileNumber, destPileNumber, cardIndex);
    }

    // if moving to empty foundation pile
    if (destination == PileType.FOUNDATION && foundationPiles.get(destPileNumber).size() == 0) {
      validateFoundationFirstCard(source, pileNumber, destPileNumber, cardIndex);
    }

    // if moving to foundation pile, make sure suits are same
    if (destination == PileType.FOUNDATION
            && foundationPiles.get(destPileNumber).size() > 0) {
      validateMoveToFoundation(source, pileNumber, destPileNumber, cardIndex);
    }

    // cascade to open
    if (source == PileType.CASCADE && destination == PileType.OPEN) {
      addRemoveCard(cascadePiles.get(pileNumber), openPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // cascade to foundation
    else if (source == PileType.CASCADE && destination == PileType.FOUNDATION) {
      addRemoveCard(cascadePiles.get(pileNumber), foundationPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // cascade to cascade
    else if (source == PileType.CASCADE && destination == PileType.CASCADE) {
      addRemoveCard(cascadePiles.get(pileNumber), cascadePiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // open to open
    else if (source == PileType.OPEN && destination == PileType.OPEN) {
      addRemoveCard(openPiles.get(pileNumber), openPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // open to foundation
    else if (source == PileType.OPEN && destination == PileType.FOUNDATION) {
      addRemoveCard(openPiles.get(pileNumber), foundationPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // open to cascade
    else if (source == PileType.OPEN && destination == PileType.CASCADE) {
      addRemoveCard(openPiles.get(pileNumber), cascadePiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // foundation to open
    else if (source == PileType.FOUNDATION && destination == PileType.OPEN) {
      addRemoveCard(foundationPiles.get(pileNumber), openPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // foundation to cascade
    else if (source == PileType.FOUNDATION && destination == PileType.CASCADE) {
      addRemoveCard(foundationPiles.get(pileNumber), cascadePiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // foundation to foundation
    else if (source == PileType.FOUNDATION && destination == PileType.FOUNDATION) {
      addRemoveCard(foundationPiles.get(pileNumber), foundationPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    } else {
      throw new IllegalArgumentException("Misc invalid move");
    }
  }

  @Override
  public boolean isGameOver() {
    // do all foundation piles have 13 cards
    return (foundationPiles.get(0).size() == 13
            && foundationPiles.get(1).size() == 13
            && foundationPiles.get(2).size() == 13
            && foundationPiles.get(3).size() == 13);
  }

  @Override
  public String getGameState() {

    if (cascadePiles == null) {
      return "";
    }

    StringBuilder output = new StringBuilder();

    // print foundation piles
    output.append(pileToString(foundationPiles, PileType.FOUNDATION));
    output.append("\n");
    output.append(pileToString(openPiles, PileType.OPEN));
    output.append("\n");
    output.append(pileToString(cascadePiles, PileType.CASCADE));

    return output.toString();
  }

  /**
   * This method takes a given pile and a type and helps correctly format the string output.
   * It adds the correct symbol, colon, spacing, and new line handling.
   *
   * @param pile Pile to be printed.
   * @param type Type to be printed.
   * @return a new string builder with appropriate formatting
   */
  protected StringBuilder pileToString(ArrayList<ArrayList<Card>> pile, PileType type) {
    StringBuilder output = new StringBuilder();

    for (int i = 0; i < pile.size(); i++) {

      // this block prints "F1:"
      output.append(type.toString());
      output.append(i + 1);
      output.append(":");

      //this block prints " 6♦"
      for (int j = 0; j < pile.get(i).size(); j++) {
        output.append(" ");
        output.append(pile.get(i).get(j).toString());

        // only append ',' while NOT last line
        if (j <= pile.get(i).size() - 2) {
          output.append(",");
        }
      }

      // only append '\n' when NOT last line
      if (i != pile.size() - 1) {
        output.append("\n");
      }
    }
    return output;
  }
}