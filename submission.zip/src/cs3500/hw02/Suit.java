package cs3500.hw02;

/**
 * Created by cWong on 1/24/17.
 */
public enum Suit {
  SPADE,
  HEART,
  DIAMOND,
  CLUB;

  /**
   * @return suit character as string.
   */
  public String toString() {

    switch (this) {
      case SPADE:
        return "♠";
      case HEART:
        return "♥";
      case DIAMOND:
        return "♦";
      case CLUB:
        return "♣";
      default:
        throw new IllegalArgumentException("I");
    }
  }
}
