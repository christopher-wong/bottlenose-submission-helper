package cs3500.hw02;

/**
 * Created by cWong on 1/21/17.
 */

/**
 * to represent a Card with a suit and value fields that are enums.
 * Card also has a color field which is red/black depending on suit which eases checking later on
 */
public class Card {

  // to represent a Card's value
  private final Value value;

  // to represent a Card's suit
  private final Suit suit;

  // to represent a Card's color
  private String color;

  /**
   * this constructor sets up the card, it also assigns color.
   *
   * @param value the numeric value of a card.
   * @param suit  one of 4 valid suits.
   */
  public Card(Value value, Suit suit) {
    this.value = value;
    this.suit = suit;

    if (suit == Suit.DIAMOND || suit == Suit.HEART) {
      this.color = "red";
    } else {
      this.color = "black";
    }
  }

  /**
   * @return a call to Value Enum's toInt() method which gets the value of the card.
   */
  public int getValue() {
    return value.toInt();
  }

  /**
   * @return This method return's the card color (either black or white).
   */
  public String getColor() {
    return color;
  }


  /**
   * @return a string representation of a card formatted properly.
   */
  public String toString() {
    return String.format("%s%s", value.toString(), suit.toString());
  }
}

