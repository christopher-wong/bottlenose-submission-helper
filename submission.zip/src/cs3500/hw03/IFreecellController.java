package cs3500.hw03;

import java.util.List;

import cs3500.hw02.FreecellOperations;

/**
 * Created by cWong on 2/1/17.
 */

/**
 * This is the interface of the Freecell Controller. It is parameterized over the
 * card type, i.e. when you implement it, you can substitute K with your
 * implementation of a card.
 */
public interface IFreecellController<K> {

  /**
   * This method should start a new game of Freecell using the parameters specified below
   *
   * <p></p>It should throw an IllegalStateException
   *
   * @param deck       A standard poker deck of 52 cards (Four suits, 13 cards per suit, no
   *                   jokers).
   * @param model      A model to be passed to the controller
   * @param numCascade The number of Cascade piles.
   * @param numOpens   The number of Open piles.
   * @param shuffle    If "shuffle" is set to false the deck must be used as-is, else the deck
   *                   should be shuffled.
   * @throws IllegalStateException This exception should be thrown only if the controller has not
   *                               been initialized properly to receive input and transmit output.
   */
  void playGame(List<K> deck, FreecellOperations<K> model, int numCascade, int numOpens,
                boolean shuffle);
}
