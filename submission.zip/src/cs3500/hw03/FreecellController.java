package cs3500.hw03;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;
import cs3500.hw02.PileType;


/**
 * Created by cWong on 2/1/17.
 */

/**
 * A class to represent the FreecellController that implements IFreecellController.
 */
public class FreecellController implements IFreecellController<Card> {

  Scanner sc;
  private FreecellOperations model;
  private Appendable ap;
  private int numCascade;
  private int numOpen;
  private String shuffleInput;
  private boolean shuffle;

  /**
   * The constructor for the freecell contrusctor
   *
   * @param rd Readable from user.
   * @param ap Appednable to user.
   */
  public FreecellController(Readable rd, Appendable ap) {

    if (rd == null || ap == null) {
      throw new IllegalStateException("Readable or Appendable is null!");
    }

    model = new FreecellModel();
    this.ap = ap;

    numCascade = 0;
    numOpen = 0;
    shuffleInput = "";
    shuffle = true;

    sc = new Scanner(rd);
  }

  @Override
  public void playGame(List<Card> deck, FreecellOperations<Card> model, int numCascade,
                       int numOpens, boolean shuffle) {

    if (deck == null || model == null) {
      throw new IllegalArgumentException("Model/Deck is null!");
    }

    // try and start game
    try {
      model.startGame(deck, numCascade, numOpens, shuffle);
    } catch (IllegalArgumentException e) {
      try {
        ap.append(String.format("Could not start game."));
        return;
      } catch (IOException ioe) {
        return;
      }
    }

    // print game state
    try {
      ap.append("\n");
      ap.append(model.getGameState());
      ap.append("\n");
      ap.append("\n");
    } catch (IOException ioe) {
      return;
    }

    while (!model.isGameOver()) {
      // temp strings from scanner
      String sourceInput;
      String destInput;
      String cardNumberInput;

      // processed pile types from scanner
      PileType sourcePileType;
      PileType destPileType;

      // processed nums from scanner
      int sourcePileNumber;
      int destPileNumber;
      int cardNumber;

      try {
        ap.append("Source Pile (e.g. C1): ");
        while (!validPileInputFormat(sourceInput = sc.next())) {
          ap.append("Invalid Pile Input, Try again: ");
        }

        if (quitGame(sourceInput)) {
          return;
        }

        sourcePileType = charToPileType(sourceInput.charAt(0));
        sourcePileNumber = Integer.parseInt(sourceInput.substring(1)) - 1;

        ap.append("Card Number (e.g.): ");
        while (!validIndexFormat(cardNumberInput = sc.next())) {
          ap.append("Invalid Card Number, Try again: ");
        }

        if (quitGame(cardNumberInput)) {
          return;
        }

        cardNumber = Integer.parseInt(cardNumberInput) - 1;

        ap.append("Destination Pile (e.g. F1): ");
        while (!validPileInputFormat(destInput = sc.next())) {
          ap.append("Invalid Pile Input, Try again: ");
        }

        if (quitGame(destInput)) {
          return;
        }

        destPileType = charToPileType(destInput.charAt(0));
        destPileNumber = Integer.parseInt(destInput.substring(1)) - 1;

        try {
          model.move(sourcePileType, sourcePileNumber, cardNumber, destPileType, destPileNumber);
        } catch (IllegalArgumentException e) {
          ap.append(String.format("\nError: %s Try again: \n", e.getMessage()));
        }

        try {
          ap.append(model.getGameState());
          ap.append("\n");
          ap.append("\n");
        } catch (IOException ioe) {
          return;
        }
      } catch (IOException e) {
        return;
      }
    }

    // this executes when player has won
    try {
      ap.append("\n");
      ap.append(model.getGameState());
      ap.append("\n");
      ap.append("Game over.");
    } catch (IOException ioe) {
      return;
    } finally {
      return;
    }
  }

  /**
   * Init game.
   */
  public void initController() {
    try {
      readGameParams();
      writeGameParams();
      playGame(model.getDeck(), model, numCascade, numOpen, shuffle);
    } catch (IOException e) {
      return;
    }
  }

  /**
   * Takes a char as an input and converts it to a PileType.
   *
   * @param c read in from the user.
   * @return The PileType of the char
   */
  private PileType charToPileType(char c) {
    switch (c) {
      case 'C':
        return PileType.CASCADE;
      case 'O':
        return PileType.OPEN;
      case 'F':
        return PileType.FOUNDATION;
      default:
        throw new IllegalArgumentException("Pile type not valid");
    }
  }

  /**
   * @throws IOException if the shuffle parameter is not either 'y' or 'n'.
   */
  public void writeGameParams() throws IOException {

    ap.append("\n");
    ap.append("# Cascade Piles: ").append(Integer.toString(numCascade));
    ap.append("\n");
    ap.append("# Open Piles: ").append(Integer.toString(numOpen));
    ap.append("\n");

    switch (shuffleInput) {
      case "y":
        ap.append("Let's shuffle!\n");
        break;
      case "n":
        ap.append("Deck in order!\n");
        break;
      default:
        throw new IllegalArgumentException("Invalid shuffle parameter!");
    }
  }

  /**
   * Read in inputs from the user.
   * Cascade Piles #, Open Piles #, Shuffle y/n.
   */
  public void readGameParams() throws IOException {

    int temp;
    do {
      ap.append("Enter number of Cascade Piles: ");
      while (!sc.hasNextInt()) {
        String input = sc.next();
        ap.append(String.format("%s is not a valid number. Try again: ", input));
      }
      temp = sc.nextInt();
    } while (temp < 0);
    numCascade = temp;

    do {
      ap.append("Enter number of Open Piles: ");
      while (!sc.hasNextInt()) {
        String input = sc.next();
        ap.append(String.format("%s is not a valid number. Try again: ", input));
      }
      temp = sc.nextInt();
    } while (temp < 0);
    numOpen = temp;

    ap.append("Do you want to shuffle (y/n): ");
    String s;
    while ((!(s = sc.next().toLowerCase()).equals("y")) && !(s.equals("n"))) {
      ap.append(String.format("%s is not a valid option. Try again: ", s));
    }

    shuffleInput = s;

    switch (shuffleInput) {
      case "y":
        shuffle = true;
        break;
      case "n":
        shuffle = false;
        break;
      default:
        throw new IllegalArgumentException("Invalid Shuffle input");
    }
  }

  /**
   * Append final game state and exit if correct key is entered.
   *
   * @param s the input string fro the user.
   */
  private boolean quitGame(String s) {
    if (s.equals("q") || s.equals("Q")) {
      try {
        ap.append("\n");
        ap.append("Game quit prematurely.");
      } catch (IOException e) {
        return false;
      }
      return true;
    }
    return false;
  }

  private boolean validIndexFormat(String s) {
    if (s.equals("Q") || s.equals("q")) {
      return true;
    }

    int index;

    try {
      index = Integer.parseInt(s);
    } catch (NumberFormatException e) {
      return false;
    }

    return index > 0;
  }

  /**
   * Validate whether or not the pile input is valid
   *
   * @param s the input string from the user.
   * @return a boolean designating if the inputs are of the correct format.
   */

  private boolean validPileInputFormat(String s) {
    if (s.equals("Q") || s.equals("q")) {
      return true;
    }

    if (s.length() < 2) {
      return false;
    }

    char pileChar = s.charAt(0);
    String numString = s.substring(1);

    int numInt;

    try {
      numInt = Integer.parseInt(numString);
    } catch (NumberFormatException e) {
      return false;
    }

    if (numInt < 0) {
      return false;
    }

    return (pileChar == 'C'
            || pileChar == 'O'
            || pileChar == 'F');
  }
}