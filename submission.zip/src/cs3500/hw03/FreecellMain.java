package cs3500.hw03;

/**
 * Created by cWong on 2/2/17.
 */

import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;

import cs3500.hw02.FreecellOperations;
import cs3500.hw04.FreecellModelCreator;

/**
 * A class to hold main method.
 */
public class FreecellMain {

  /**
   * Main method to allow user testing of the program.
   */
  public static void main(String[] args) {

    Reader reader = new InputStreamReader(System.in);
    PrintStream writer = System.out;

    FreecellController controller = new FreecellController(reader, writer);
    FreecellModelCreator creator = new FreecellModelCreator();
    FreecellOperations model = FreecellModelCreator.create(FreecellModelCreator.GameType.MULTIMOVE);

    controller.playGame(model.getDeck(), model, 52, 4, false);

    //    try {
    //      controller.initController();
    //    } catch (IllegalArgumentException e) {
    //      return;
    //    }
  }
}
