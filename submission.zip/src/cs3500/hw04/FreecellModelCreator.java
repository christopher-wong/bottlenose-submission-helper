package cs3500.hw04;

import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;

/**
 * Created by cWong on 2/13/17.
 */
public class FreecellModelCreator {

  /**
   * Default constructor.
   */
  public FreecellModelCreator() {
    // do nothing.
  }

  /**
   * @param type of game, either single or multi.
   * @return Return new FreecellOperations object.
   */
  public static FreecellOperations create(GameType type) {
    switch (type) {
      case SINGLEMOVE:
        return new FreecellModel();
      case MULTIMOVE:
        return new FreecellModelMulti();
      default:
        throw new IllegalArgumentException("Invalid Game Type!");
    }
  }

  /**
   * An enum to represent two different game types.
   */
  public enum GameType {
    SINGLEMOVE, MULTIMOVE
  }
}
