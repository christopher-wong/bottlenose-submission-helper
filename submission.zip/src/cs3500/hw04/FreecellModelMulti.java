package cs3500.hw04;

import java.util.ArrayList;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;
import cs3500.hw02.PileType;

/**
 * Created by cWong on 2/13/17.
 */

public class FreecellModelMulti extends FreecellModel implements FreecellOperations<Card> {

  @Override
  protected void validCardIndex(PileType source, int pileIndex, int
          cardIndex) {

    if (cardIndex < 0 || cardIndex > pileConvert(source).get(pileIndex).size() - 1) {
      throw new IllegalArgumentException("Cannot move this card!");
    }
  }

  private double maxNumMovableCards() {
    // number of free open piles
    int n = 0;
    // number of free cascade piles
    int k = 0;

    int j = 0;
    while (j < openPiles.size()) {
      if (openPiles.get(j).size() == 0) {
        n++;
        j++;
      } else {
        j++;
      }
    }

    int i = 0;
    while (i < cascadePiles.size()) {
      if (cascadePiles.get(i).size() == 0) {
        k++;
        i++;
      }
      i++;
    }

    double output = (n + 1) * Math.pow(2, k);
    return output;
  }

  private int countEmptyPiles() {
    int emptyPiles = 0;

    int i = 0;
    while (i < cascadePiles.size()) {
      if (cascadePiles.get(i).size() == 0) {
        emptyPiles++;
        i++;
      }
      i++;
    }

    int j = 0;
    while (j < openPiles.size()) {
      if (openPiles.get(j).size() == 0) {
        emptyPiles++;
        j++;
      } else {
        j++;
      }
    }
    return emptyPiles;
  }

  @Override
  protected void addRemoveCard(ArrayList<Card> fromPile, ArrayList<Card> toPile, int cardIndex,
                               int pileNumber, int destPileNumber) throws IllegalArgumentException {

    if (cardIndex > fromPile.size() - 1) {
      throw new IllegalArgumentException("Pile size invalid");
    }

    int cardsToMoveCount = fromPile.size() - cardIndex;

    if (cardIndex == fromPile.size() - 1) {
      Card cardToMove = fromPile.get(cardIndex);
      // add card to destination pile
      toPile.add(cardToMove);
      // delete card from source pile
      fromPile.remove(cardToMove);
    } else if (cardIndex < fromPile.size() - 1 && countEmptyPiles() >= cardsToMoveCount) {
      for (int i = cardIndex; i < fromPile.size(); i++) {
        Card cardToMove = fromPile.get(i);
        // add card to destination pile
        toPile.add(cardToMove);
      }
      while (cardIndex < cascadePiles.get(pileNumber).size()) {
        // delete card from source pile
        fromPile.remove(cardIndex);
      }
    }
  }

  protected void validateMoveToCascade(PileType source, PileType destination, int pileNumber,
                                       int
                                               destPileNumber, int cardIndex) {

    // if dest pile is empty AND card to be added is a king, BAD!
    if (pileConvert(source).get(pileNumber).size() == 0 && pileConvert(source).get(pileNumber).get(
            cardIndex).getValue() == 13) {
      throw new IllegalArgumentException("Cannot add King to empty cascade pile!");
    }

    if (cardIndex < pileConvert(source).get(pileNumber).size() - 1) {
      // validate source build
      for (int i = cardIndex; i < pileConvert(source).get(pileNumber).size() - 1; i++) {

        int cardsInBuild = pileConvert(source).get(pileNumber).size() - cardIndex;

        Card currCard = pileConvert(source).get(pileNumber).get(i);
        Card nextCard = pileConvert(source).get(pileNumber).get(i + 1);

        if (currCard.getValue() - 1 != nextCard.getValue()
                || currCard.getColor() == nextCard.getColor()
                || countEmptyPiles() < (((pileConvert(source).get(pileNumber).size() - 1)
                - cardIndex))) {
          throw new IllegalArgumentException("Can't move, invalid build!");
        }
      }
    }

    if (pileConvert(destination).get(destPileNumber).size() == 0) {
      return;
    }

    int lastCardIndex = pileConvert(destination).get(destPileNumber).size() - 1;

    if (pileConvert(source).get(pileNumber).get(cardIndex).getColor().equals(
            pileConvert(destination).get(destPileNumber).get(lastCardIndex).getColor())

            || pileConvert(source).get(pileNumber).get(cardIndex).getValue()
            + 1 != pileConvert(destination).get(destPileNumber).get(lastCardIndex).getValue()) {
      throw new IllegalArgumentException("Cannot move this card!");
    }
  }

  @Override
  public void move(PileType source, int pileNumber, int cardIndex, PileType destination,
                   int destPileNumber) throws IllegalArgumentException {

    // if piles are null
    if (foundationPiles == null || cascadePiles == null || openPiles == null) {
      throw new IllegalArgumentException("Game has not started!");
    }

    // if game is over
    if (isGameOver()) {
      throw new IllegalArgumentException("Game is over!");
    }

    // if inputs are negative
    if (pileNumber < 0 || cardIndex < 0 || destPileNumber < 0) {
      throw new IllegalArgumentException("Inputs are negative!");
    }

    // does source pile exist?
    doesPileExist(source, pileNumber);

    // does dest pile exist?
    doesPileExist(destination, destPileNumber);

    // only allowed to move last card in cascade pile or foundation pile
    validCardIndex(source, pileNumber, cardIndex);

    // if open piles are full
    if (destination == PileType.OPEN && openPiles.get(destPileNumber).size() >= 1) {
      throw new IllegalArgumentException("Open pile is full!");
    }

    // if moving to cascade pile, make sure suits are different and card is 1 less in value
    if (destination == PileType.CASCADE && destPileNumber <= cascadePiles.size()) {
      validateMoveToCascade(source, destination, pileNumber, destPileNumber, cardIndex);
    }

    // if moving to empty foundation pile
    if (destination == PileType.FOUNDATION && foundationPiles.get(destPileNumber).size() == 0) {
      validateFoundationFirstCard(source, pileNumber, destPileNumber, cardIndex);
    }

    // if moving to foundation pile, make sure suits are same
    if (destination == PileType.FOUNDATION
            && foundationPiles.get(destPileNumber).size() > 0) {
      validateMoveToFoundation(source, pileNumber, destPileNumber, cardIndex);
    }

    // cascade to open
    if (source == PileType.CASCADE && destination == PileType.OPEN) {
      addRemoveCard(cascadePiles.get(pileNumber), openPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // cascade to foundation
    else if (source == PileType.CASCADE && destination == PileType.FOUNDATION) {
      addRemoveCard(cascadePiles.get(pileNumber), foundationPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // cascade to cascade
    else if (source == PileType.CASCADE && destination == PileType.CASCADE) {
      addRemoveCard(cascadePiles.get(pileNumber), cascadePiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // open to open
    else if (source == PileType.OPEN && destination == PileType.OPEN) {
      addRemoveCard(openPiles.get(pileNumber), openPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // open to foundation
    else if (source == PileType.OPEN && destination == PileType.FOUNDATION) {
      addRemoveCard(openPiles.get(pileNumber), foundationPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // open to cascade
    else if (source == PileType.OPEN && destination == PileType.CASCADE) {
      addRemoveCard(openPiles.get(pileNumber), cascadePiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // foundation to open
    else if (source == PileType.FOUNDATION && destination == PileType.OPEN) {
      addRemoveCard(foundationPiles.get(pileNumber), openPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // foundation to cascade
    else if (source == PileType.FOUNDATION && destination == PileType.CASCADE) {
      addRemoveCard(foundationPiles.get(pileNumber), cascadePiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    }

    // foundation to foundation
    else if (source == PileType.FOUNDATION && destination == PileType.FOUNDATION) {
      addRemoveCard(foundationPiles.get(pileNumber), foundationPiles.get(destPileNumber), cardIndex,
              pileNumber, destPileNumber);
    } else {
      throw new IllegalArgumentException("Misc invalid move");
    }
  }
}
